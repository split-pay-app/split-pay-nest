export class AuthenticationDto {
  password: string;
  uniqueKey: string;
}

export class CreatePaymentMadeRequestDto {
  debitId: string;
}

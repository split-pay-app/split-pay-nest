export class VerifyTokenDto {
  entity: string;
  token: string;
}

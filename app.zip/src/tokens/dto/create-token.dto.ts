export class CreateTokenDto {
  type: string;
  entity: string;
  token: string;
}

export class AddPayerDto {
  userId: string;
  weight: 1;
}

export class EditPayerDto {
  weight: number;
}
